# CitySentinel
### Agentic AI for Future Cities — ChronoForge Hackathon Prototype

CitySentinel is a prototype urban-incident intelligence platform. It analyzes sample city incident data, prioritizes risk, recommends response actions, and records a verification checklist. It is designed to support human decision-makers—not to autonomously control city infrastructure.

## Prototype capabilities
- View sample urban incidents in a dashboard.
- Filter and inspect incident details.
- Score risk using transparent, rule-based logic.
- Generate response recommendations.
- Mark recommendations as reviewed and record a verification note.
- Run locally without API keys or paid AI services.

> **Prototype limitation:** The included data is synthetic. The current risk and recommendation logic is deterministic and rule-based, not a live multi-agent AI system. No real city systems are connected and no actions are executed automatically.

## Tech stack
- Frontend: React + Vite
- Backend: Python + FastAPI
- Data: local JSON sample dataset
- Charts: Recharts

## Run locally

### 1. Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
API: http://127.0.0.1:8000  
Docs: http://127.0.0.1:8000/docs

### 2. Frontend
Open a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the local URL printed by Vite (normally http://localhost:5173).

The frontend expects the API at `http://127.0.0.1:8000`. Change `VITE_API_URL` if needed.

## API endpoints
- `GET /health`
- `GET /api/incidents`
- `GET /api/incidents/{incident_id}`
- `POST /api/incidents/{incident_id}/review`

## Suggested next steps
1. Connect trusted live/open city data sources.
2. Add authentication and role-based access.
3. Replace rules with validated forecasting/anomaly models where appropriate.
4. Add audit logs, data-quality checks, and model evaluation.
5. Keep human approval for consequential actions.

## Team
Team TS — ChronoForge Hackathon
