import React, { useEffect, useMemo, useState } from "react";
import { Activity, AlertTriangle, ArrowUpRight, CheckCircle2, Clock3, MapPin, Radio, ShieldCheck, Siren, Users, RefreshCw } from "lucide-react";

const API = import.meta.env.VITE_API_URL || "http://127.0.0.1:8000";
const fallback = [
 {id:"INC-1001",type:"Urban flooding",title:"Waterlogging near Central Market",location:"Central Market, Zone A",severity:5,people_affected:420,age_hours:1.5,status:"Open",risk_score:91,risk_level:"Critical",recommendation:"Prioritize immediate human review. Inspect drainage and assess safe route diversions.",source:"Synthetic demo data"},
 {id:"INC-1002",type:"Traffic congestion",title:"Traffic slowdown at East Junction",location:"East Junction, Zone B",severity:3,people_affected:850,age_hours:2,status:"Investigating",risk_score:86,risk_level:"Critical",recommendation:"Prioritize immediate human review. Verify congestion reports and coordinate traffic management.",source:"Synthetic demo data"},
 {id:"INC-1003",type:"Power outage",title:"Power interruption in residential block",location:"Green Park, Zone C",severity:4,people_affected:260,age_hours:.8,status:"Open",risk_score:77,risk_level:"Critical",recommendation:"Prioritize immediate human review. Notify the utility response team and confirm public-safety impacts.",source:"Synthetic demo data"},
 {id:"INC-1004",type:"Waste management",title:"Overflowing public waste bin",location:"Riverwalk, Zone A",severity:2,people_affected:70,age_hours:10,status:"Reported",risk_score:37,risk_level:"Moderate",recommendation:"Schedule review based on local operating procedures. Dispatch an inspection.",source:"Synthetic demo data"},
 {id:"INC-1005",type:"Road hazard",title:"Damaged road surface reported",location:"North Avenue, Zone D",severity:3,people_affected:180,age_hours:5,status:"Open",risk_score:57,risk_level:"High",recommendation:"Prioritize immediate human review. Send a field team to validate the report.",source:"Synthetic demo data"},
 {id:"INC-1006",type:"Urban flooding",title:"Drain overflow near school",location:"Lake Road, Zone C",severity:4,people_affected:310,age_hours:3,status:"Investigating",risk_score:76,risk_level:"Critical",recommendation:"Prioritize immediate human review. Inspect drainage and assess safe route diversions.",source:"Synthetic demo data"}
];

function RiskBadge({level}) { return <span className={`badge ${(level||"low").toLowerCase()}`}>{level || "Unscored"}</span>; }
function App() {
 const [incidents,setIncidents]=useState([]);
 const [selected,setSelected]=useState(null);
 const [filter,setFilter]=useState("All");
 const [query,setQuery]=useState("");
 const [apiState,setApiState]=useState("Connecting");
 const [reviewer,setReviewer]=useState("City Operations Team");
 const [note,setNote]=useState("");
 const [message,setMessage]=useState("");
 const [busy,setBusy]=useState(false);

 async function load() {
   setBusy(true);
   try {
     const r=await fetch(`${API}/api/incidents`);
     if(!r.ok) throw new Error("API unavailable");
     const data=await r.json(); setIncidents(data); setApiState("Live API");
   } catch(e) { setIncidents(fallback); setApiState("Demo fallback"); }
   finally {setBusy(false);}
 }
 useEffect(()=>{load();},[]);
 const filtered=useMemo(()=>incidents.filter(i=>(filter==="All"||i.risk_level===filter)&&`${i.title} ${i.type} ${i.location}`.toLowerCase().includes(query.toLowerCase())),[incidents,filter,query]);
 const critical=incidents.filter(i=>["Critical","High"].includes(i.risk_level)).length;
 const people=incidents.reduce((s,i)=>s+(Number(i.people_affected)||0),0);
 const zones=new Set(incidents.map(i=>i.location?.split(",").pop()?.trim())).size;
 async function review(approved) {
   if(!selected) return;
   setMessage("");
   try {
     const r=await fetch(`${API}/api/incidents/${selected.id}/review`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({reviewed_by:reviewer,note,approved})});
     if(!r.ok) throw new Error("API review endpoint unavailable");
     const data=await r.json();
     setIncidents(prev=>prev.map(i=>i.id===selected.id?data.incident:i));
     setSelected(data.incident); setMessage("Review saved in API demo memory.");
   } catch(e) {
     const updated={...selected,review:{reviewed_by:reviewer,note,approved}};
     setSelected(updated); setIncidents(prev=>prev.map(i=>i.id===selected.id?updated:i));
     setMessage("Review shown locally only; start the backend to persist it for this session.");
   }
 }
 return <div className="app-shell">
  <aside className="sidebar">
   <div className="brand"><div className="brand-mark"><Activity size={23}/></div><div><b>CitySentinel</b><small>URBAN INTELLIGENCE</small></div></div>
   <div className="nav-label">WORKSPACE</div><div className="nav-item active"><Activity size={17}/> Incident overview</div><div className="nav-item"><MapPin size={17}/> City operations</div><div className="nav-item"><ShieldCheck size={17}/> Review & response</div>
   <div className="side-bottom"><div className="status-dot"></div><div><b>Prototype environment</b><small>Synthetic city data only</small></div></div>
  </aside>
  <main className="main">
   <header className="topbar"><div><div className="eyebrow">FUTURE CITIES / OPERATIONS CENTER</div><h1>Urban incident intelligence</h1><p className="subtitle">Detect signals. Prioritize risk. Support human decisions.</p></div><div className="top-actions"><span className={`connection ${apiState==="Live API"?"online":""}`}><span/> {apiState}</span><button className="icon-btn" onClick={load} title="Refresh" aria-label="Refresh"><RefreshCw size={17}/></button><div className="avatar">TS</div></div></header>
   <section className="notice"><Radio size={18}/><div><b>Decision-support mode</b><span>Recommendations are advisory. No city infrastructure is controlled automatically.</span></div><span className="demo-tag">DEMO DATA</span></section>
   <section className="metrics">
    <div className="metric"><div className="metric-top"><span>Incidents tracked</span><span className="metric-icon"><Siren size={18}/></span></div><strong>{incidents.length}</strong><small><span className="muted">Across current sample</span></small></div>
    <div className="metric"><div className="metric-top"><span>High-priority signals</span><span className="metric-icon alert"><AlertTriangle size={18}/></span></div><strong>{critical}</strong><small><span className="accent">Needs human review</span></small></div>
    <div className="metric"><div className="metric-top"><span>People potentially affected</span><span className="metric-icon"><Users size={18}/></span></div><strong>{people.toLocaleString()}</strong><small><span className="muted">Reported estimates, not verified</span></small></div>
    <div className="metric"><div className="metric-top"><span>Zones represented</span><span className="metric-icon"><MapPin size={18}/></span></div><strong>{zones}</strong><small><span className="muted">Synthetic locations</span></small></div>
   </section>
   <section className="content-grid">
    <div className="panel incidents-panel"><div className="panel-heading"><div><h2>Incident queue</h2><p>Prioritized using transparent demo risk rules</p></div><span className="count-pill">{filtered.length} records</span></div>
     <div className="controls"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search incidents or locations…" aria-label="Search incidents"/><select value={filter} onChange={e=>setFilter(e.target.value)} aria-label="Filter risk"><option>All</option><option>Critical</option><option>High</option><option>Moderate</option><option>Low</option></select></div>
     <div className="table-wrap"><table><thead><tr><th>INCIDENT</th><th>RISK</th><th>AFFECTED</th><th>STATUS</th><th></th></tr></thead><tbody>{filtered.map(i=><tr key={i.id} onClick={()=>{setSelected(i);setNote(i.review?.note||"");setMessage("");}} className={selected?.id===i.id?"selected":""}><td><div className="incident-title">{i.title}</div><div className="subcell">{i.id} · {i.location}</div></td><td><RiskBadge level={i.risk_level}/><div className="score">{i.risk_score}/100</div></td><td>{Number(i.people_affected).toLocaleString()}</td><td><span className="status-label">{i.status}</span></td><td><ArrowUpRight size={16}/></td></tr>)}</tbody></table></div>
     <div className="table-foot"><span><span className="live-dot"></span> {busy?"Refreshing records…":"Queue updated from current demo source"}</span><span>Click a row to inspect →</span></div>
    </div>
    <div className="panel detail-panel">{selected?<><div className="panel-heading"><div><div className="eyebrow">INCIDENT DETAIL</div><h2>{selected.title}</h2><p>{selected.id} · {selected.location}</p></div><RiskBadge level={selected.risk_level}/></div>
      <div className="risk-score"><div><span>DEMO RISK SCORE</span><strong>{selected.risk_score}<small>/100</small></strong></div><div className="score-track"><div style={{width:`${selected.risk_score}%`}}/></div></div>
      <div className="detail-facts"><div><span>Incident type</span><b>{selected.type}</b></div><div><span>Severity input</span><b>{selected.severity}/5</b></div><div><span>Reported age</span><b>{selected.age_hours} hours</b></div><div><span>Potential impact</span><b>{Number(selected.people_affected).toLocaleString()} people</b></div></div>
      <div className="recommendation"><div className="rec-icon"><ShieldCheck size={18}/></div><div><b>Recommended next step</b><p>{selected.recommendation}</p><small>Validate details with an authorized city operator before action.</small></div></div>
      <div className="review-form"><h3><CheckCircle2 size={17}/> Human review log</h3><label>Reviewer / team<input value={reviewer} onChange={e=>setReviewer(e.target.value)} /></label><label>Verification note<textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="What evidence was checked? What remains uncertain?" rows="3"/></label><div className="review-actions"><button className="secondary" onClick={()=>review(false)}>Mark reviewed</button><button className="primary" onClick={()=>review(true)}>Approve recommendation</button></div>{message&&<p className="feedback">{message}</p>}{selected.review&&<p className="review-state">Last demo review: {selected.review.reviewed_by} · {selected.review.approved?"Approved":"Reviewed"}</p>}</div>
     </>:<div className="empty-detail"><div className="empty-icon"><Clock3 size={25}/></div><h2>Select an incident</h2><p>Choose an item from the queue to review its risk score, recommended response, and verification log.</p></div>}</div>
   </section>
   <footer><span>CitySentinel <b>·</b> ChronoForge prototype</span><span>Rule-based scoring · Synthetic data · Human-in-the-loop</span></footer>
  </main>
 </div>;
}
export default App;
