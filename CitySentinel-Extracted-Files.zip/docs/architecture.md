# CitySentinel architecture (prototype)

```text
Synthetic incident JSON
        |
        v
FastAPI incident API
        |
        +--> Transparent risk scoring rules
        +--> Recommendation rules
        +--> Human review endpoint (in-memory demo record)
        |
        v
React + Vite operations dashboard
        |
        +--> Incident queue and search
        +--> Risk detail and recommendation
        +--> Review / approve controls
```

## Agentic workflow target (future implementation)
1. **Urban Data Agent:** ingest data and check freshness/completeness.
2. **Investigation Agent:** assemble supporting evidence and identify gaps.
3. **Risk Assessment Agent:** estimate impact with explainable factors.
4. **Planning Agent:** suggest response options with constraints.
5. **Verification Agent:** check whether the chosen intervention achieved its intended result.
6. **Human approval:** authorized operators approve consequential actions.

These agent roles are the proposed design. The current implementation uses simple deterministic rules and does not run independent LLM agents.

## Safety and reliability boundaries
- Sample data is synthetic and must not be used for real emergency decisions.
- Scores are illustrative and have not been calibrated or validated.
- Recommendations are advisory only.
- The review endpoint stores its record in memory; it is not durable audit storage.
- Live integrations, authentication, authorization, and production security are not implemented.
