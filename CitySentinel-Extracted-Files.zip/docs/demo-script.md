# 2-minute demo script

1. Open the dashboard and explain that CitySentinel is an urban incident decision-support prototype.
2. Point out the demo-data banner and explain that no real city systems are connected.
3. Select the waterlogging incident. Explain the risk score inputs and show the recommendation.
4. Explain that the system suggests actions but does not execute them.
5. Add a reviewer name and verification note, then mark reviewed or approve the recommendation.
6. Close by describing the proposed next stage: validated open-data integrations, evidence checks, and agent-based investigation with human approval.

**One-line pitch:** CitySentinel turns fragmented urban incident reports into explainable risk priorities and human-reviewed response recommendations.
