from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from pathlib import Path
import json

app = FastAPI(
    title="CitySentinel API",
    description="Prototype API for urban incident risk analysis and human-reviewed recommendations.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DATA_FILE = Path(__file__).resolve().parents[1] / "data" / "incidents.json"
with DATA_FILE.open("r", encoding="utf-8") as f:
    INCIDENTS = json.load(f)

class ReviewPayload(BaseModel):
    reviewed_by: str = Field(min_length=1, max_length=80)
    note: str = Field(default="", max_length=500)
    approved: bool = False

def enrich(item: dict) -> dict:
    """Transparent demo scoring. Not a validated emergency model."""
    severity = int(item.get("severity", 1))
    people = int(item.get("people_affected", 0))
    age_hours = float(item.get("age_hours", 0))
    score = min(100, severity * 14 + min(people, 500) * 0.08 + max(0, 24 - age_hours) * 0.5)
    if score >= 70:
        level = "Critical"
    elif score >= 48:
        level = "High"
    elif score >= 25:
        level = "Moderate"
    else:
        level = "Low"
    return {
        **item,
        "risk_score": round(score),
        "risk_level": level,
        "recommendation": recommendation_for(item, level),
    }

def recommendation_for(item: dict, level: str) -> str:
    kind = item.get("type", "").lower()
    if "flood" in kind or "waterlogging" in kind:
        action = "Inspect drainage and assess safe route diversions."
    elif "traffic" in kind or "road" in kind:
        action = "Verify congestion reports and coordinate traffic management."
    elif "power" in kind or "electric" in kind:
        action = "Notify the utility response team and confirm public-safety impacts."
    elif "waste" in kind or "sanitation" in kind:
        action = "Dispatch an inspection and assess nearby public-health impact."
    else:
        action = "Send a field team to validate the report and identify safe next steps."
    priority = "Prioritize immediate human review." if level in ("Critical", "High") else "Schedule review based on local operating procedures."
    return f"{priority} {action}"

@app.get("/health")
def health():
    return {"status": "ok", "service": "CitySentinel API", "mode": "synthetic-data-demo"}

@app.get("/api/incidents")
def list_incidents():
    return [enrich(i) for i in INCIDENTS]

@app.get("/api/incidents/{incident_id}")
def get_incident(incident_id: str):
    item = next((i for i in INCIDENTS if i["id"] == incident_id), None)
    if not item:
        raise HTTPException(status_code=404, detail="Incident not found")
    return enrich(item)

@app.post("/api/incidents/{incident_id}/review")
def review_incident(incident_id: str, payload: ReviewPayload):
    item = next((i for i in INCIDENTS if i["id"] == incident_id), None)
    if not item:
        raise HTTPException(status_code=404, detail="Incident not found")
    # In-memory demonstration only; review records reset when the server restarts.
    item["review"] = {
        "reviewed_by": payload.reviewed_by,
        "note": payload.note,
        "approved": payload.approved,
    }
    return {"ok": True, "incident": enrich(item), "message": "Review recorded in demo memory."}
